module.exports = {
  reactStrictMode: true,
  images: {
    domains: ['assets.codigohabil.com',  'wp.codigohabil.com'],
  }
}
