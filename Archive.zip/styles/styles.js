const css = {
    colors:{
        primary: '#7D9091',
        dark: '#283940',
    }
}

export default css