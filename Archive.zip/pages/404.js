import React from 'react';
import Header from '../components/Header';
import NotFoundSection from '../components/NotFoundSection';



const NotFound = () => {
  return <div>
      <Header/>
      <NotFoundSection/>
  </div>;
};


export default NotFound;
